<nav class="purple darken-2 navbar-fixed saira">
            <div class="nav-wrapper container">
                <a href="#" class="brand-logo hide-on-small-only">Max & Heiko</a>
                <a href="#" class="brand-logo hide-on-med-and-up center-align">Max & Heiko</a>
                <a href="#" class="sidenav-trigger" data-target="mobile-links">
                    <i class="material-icons">menu</i>
                </a>

                <ul class="right hide-on-med-and-down">
                    <li><a href="../index.php">Présentation</a></li>
                    <li><a href="../html/projet1.php">Projet 1</a></li>
                    <li><a href="../html/projet2.php">Projet 2</a></li>
                    <li><a href="../html/projet3.php">Projet 3</a></li>
                    <li><a href="../html/form.php">Contact</a></li>
                    <li><a href="../html/inscription.php">Inscription</a></li>
                    <li><a href="../html/login.php">Login</a></li>
                </ul>
            </div>
        </nav>

        <ul class="sidenav" id="mobile-links">
            <li><a href="../index.php">Présentation</a></li>
            <li><a href="../html/projet1.php">Projet 1</a></li>
            <li><a href="../html/projet2.php">Projet 2</a></li>
            <li><a href="../html/projet3.php">Projet 3</a></li>
            <li><a href="#contact" class="modal-trigger">Contact</a></li>
            <li><a href="../html/inscription.php">Inscription</a></li>
            <li><a href="../html/login.php">Login</a></li>
        </ul>