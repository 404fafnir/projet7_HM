<footer class="page-footer purple darken-2 foo saira">
            <div class="container">
                <div class="row valign-wrapper">
                    <div class="col s6">
                        <h3>
                            A Propos 
                        </h3>

                        <p>Ce site a été conçus dans le cadre d'un projet noté pour l'école Guardia Cybersecurity School en Novembre 2022</p>
                    </div>
                    <div class="col s6 center-align iconsfo">
                        <i class="material-icons">chat</i>
                        <i class="material-icons">call</i>
                        <i class="material-icons">description</i>
                        <i class="material-icons">edit</i>
                    </div>
                </div>
            </div>
            <div class="footer-copyright foo">
                <div class="container">
                   <p>© 2022 Copyright Max&Heiko</p>
                </div>
            </div>
        </footer>