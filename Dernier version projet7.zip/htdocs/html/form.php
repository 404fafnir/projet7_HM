<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include "../phpimports/StyleImports.php"; ?>
        <?php require "../config/config.php"; ?>
        <title>Form</title>
    </head>
    <body>
        <?php include "../phpimports/navbar.php"; ?>
        <div class="container center">
            <form action="sendform.php" method="post">
                <ul>
                    <li>
                        <label for="fname">Veuillez remplir votre prénom :</label>
                        <input type="text" name="firstname">
                    </li>
                    <li>
                        <label for="lname">Veuillez remplir votre nom de famille :</label>
                        <input type="text" name="lastname">
                    </li>
                    <li>
                        <label for="msg">Veuillez remplir le message que vous souhaitez nous transmettre :</label>
                        <input type="text" name="message">
                    </li>
                    <li>
                        <button type="submit" name="submits" value="OK">
                            Envoyer
                        </button>
                    </li>
                </ul>
            </form>
        </div>
    </body>
</html>