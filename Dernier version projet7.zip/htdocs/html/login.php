
<?php 
require "../config/config.php"; ?>


<?php
$sql = "SELECT * FROM user WHERE email=:email AND password=:password"; 
$pre = $pdo->prepare($sql);
$pre->bindParam("email", $_POST['email']);
$pre->bindParam("password", $_POST['password']);
$pre->execute();
$user = $pre->fetch(PDO::FETCH_ASSOC);

if(empty($user)){ //vérifie si le resultat est vide !
        //non connecté
    echo "Utilisateur ou mot de passe incorrect !";
    header('Location:connexion.php');
}else{
    $_SESSION['user'] = $user; //on enregistre que l'utilisateur est connecté
    header('Location:logedin.php');//on le redirige sur la page d'accueil du site !
}


?>