<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include "../phpimports/StyleImports.php"; ?>
        <?php require "../config/config.php"; ?>
        <title>Presentation</title>
    </head>
    <body>
            <div class="s12 row">
                <div class="col s6 bor">
                    <h2 class="play flow-text">Maxence</h2>
                    <img class="responsive-img" src="img/Maxence.png" alt="photo de max" onmouseover="changeimage1(1,this)" onmouseout="changeimage1(2,this)">
                    <p class="josefin">Maxence Senetaire, 20 ans en première année à Guardia CyberSecurity School, possédant deux titres professionnels en informatique.</p>
                </div>
                <div class="col s6 bor">
                    <h2 class="play flow-text">Heiko</h2>
                    <img class="responsive-img" src="img/Heiko.jpg" alt="photo de heiko" onmouseover="changeimage2(1,this)" onmouseout="changeimage2(2,this)">
                    <p class="josefin">Heiko Carlier, 22 ans en première année à Guardia CyberSecurity School, précédement en prépa intégrée à EPITA Toulouse.</p>
                </div>
            </div>
    </body>
</html>