<?php 
require "../config/config.php"; 
    if(isset($_POST['submits']))
    {
        if(!empty($_POST['firstname']) AND !empty($_POST['lastname']) AND !empty($_POST['message']))
        {
            $sql = "INSERT INTO form (firstname, lastname, message) VALUES (:firstname,:lastname,:message)";
            $pre = $pdo->prepare($sql);
            $pre->bindParam("firstname", htmlspecialchars($_POST['firstname']));
            $pre->bindParam("lastname", htmlspecialchars($_POST['lastname']));
            $pre->bindParam("message", htmlspecialchars($_POST['message']));
            $pre->execute();
            header('Location:../index.php');
        } else {
            echo "Veuillez compléter le document si vovus voulez nous contacter !";
        }
    }
?>