    <script src="../js/jquery.min.js" charset="utf-8"></script>
    <script type="text/javascript" src="../js/materialize.min.js"></script>
    <script src="../js/script.js" charset="utf-8"></script>