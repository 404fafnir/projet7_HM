<?php 
    if(isset($_POST['submit']))
    {
        if(isset($_POST['firstname']) AND isset($_POST['lastname']) AND isset($_POST['message']))
        {
            if(!empty($_POST['firstname']) AND !empty($_POST['lastname']) AND !empty($_POST['message']))
            {
                $firstname=htmlspecialchars($_POST["firstname"]);
                $lastname=htmlspecialchars($_POST["lastname"]);
                $message=htmlspecialchars($_POST["message"]);

                header("Location:../index.php");
            }
        }
    }
?>