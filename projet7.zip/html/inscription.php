<?php require "../config/config.php"; ?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inscription</title>
    <?php require "../phpimports/StyleImports.php" ?>
</head>
<body>

<div class="container row">
    <h1 class="col s12">INSCRIT TOI</h1>
        <div class="col s12">
            <form method="post" action="signup.php">
                <input type='username' name='username' placeholder="username">
                <input type='email' name='email' placeholder="email">
                <input type='password' name='password' placeholder="password">
                <button class="btn waves-effect waves-light" type="submit" name="action">Submit
                    <i class="material-icons right">send</i>
                </button>
            </form>
        </div>
    <h2>Si tu as déjà un compte clic ici :</h2>
    <a href="connexion.php">connexion</a>
</div>
</body>


<?php require "../phpimports/ScriptImports.php" ?>

</html>







