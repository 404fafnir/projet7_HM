<?php require "../config/config.php"; ?>
<?php require "../phpimports/StyleImports.php" ?>
<html>
<h1>Vous êtes bien inscrit sur notre site</h1>  

<div class="container ">
    <a class="waves-effect waves-light btn-small" href="connexion.php">connexion</a>
</div>


</html>


<form action="deconnexion.php" method="post">
<button>deconnexion</button>
</form>